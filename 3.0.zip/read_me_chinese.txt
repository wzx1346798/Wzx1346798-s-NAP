﻿感谢你下载本数据包！

Wzx1346798's Adv Pack Refresh 
版本：3.0 内部版本：[20.3.0] （refresh_release.230910-1012）
作者：wzx1346798
在使用本数据包之前，请先阅读需求以及注意事项。

1.依赖项
Minecraft：1.20-1.20.1
Minecraft mods：Advancement Info（Fabric，用于详细查看进度完成情况，可选）
资源包：lang.zip文件
操作系统：Windows 10 （1903版本及以上）或 Windows 11

2.安装
本数据包需要在 Minecraft 1.20-1.20.1 版本进行。
当前下载的zip文件不是数据包主体，需要如下步骤：
1) 复制lang.zip和moa-1.20.zip。
2) 将lang.zip复制到.minecraft/resourcepacks文件夹。若有版本隔离，则复制到.minecraft/versions/1.20.1/resourcepacks文件夹。
3) 打开 Minecraft 1.20-1.20.1， 点击选项-资源包，启用刚复制的lang.zip资源包。
4) 创建新世界，导入本数据包。
5) 确保显示的描述是“Wzx1346798's Adv Pack”而不是“pack.version2.moa”。

3.内容
本数据包一共添加了650+个进度与挑战，一共790+16（806）个。

Wzx1346798's Adv Pack Refresh
©2019-2023 Wzx1346798. All rights reserved.
前言上传于2022年6月16日
更新于2023年9月10日