﻿感谢你下载本数据包！

Wzx1346798's Numerous Adv Pack
版本：3.2.4 [21.10.0] 
作者：wzx1346798
在使用本数据包之前，请先阅读需求以及注意事项。

1.环境
Minecraft：1.20-1.20.2
资源包：lang.zip文件
操作系统：Windows 10 （1903版本及以上）或 Windows 11

2.安装
本数据包需要在 Minecraft 1.20-1.20.2 版本进行。
当前下载的zip文件不是数据包主体，需要如下步骤：
1) 解压本数据包，会出现lang.zip和moa-1.20.zip。（这两个zip文件不要解压！）
2) 将lang.zip复制到.minecraft/resourcepacks文件夹或.minecraft/versions/<版本>/resourcepacks（如果开启隔离）。
3) 打开 Minecraft 1.20-1.20.2， 点击选项-资源包，启用刚复制的lang.zip资源包。
4) 创建新世界，导入本数据包。
5) 确保显示的描述是“Wzx1346798's Numerous Adv Pack 版本”而不是“pack.version2.moa”。

注意：该数据包会自动启用收纳袋实验性数据包！没有开启实验性的存档谨慎安装！

3.内容
本数据包一共添加了700+个进度与挑战，一共824+16（840）个。

4.FAQ
Q: 资源包显示不兼容？
A：直接忽略不兼容的提示。因为资源包内只包含zh_cn.json。只要在1.13+都能识别出来。

Q：数据包显示不兼容？
A：请核对安装的版本与该版本兼容的Minecraft版本是否一致。如果有疑问，可以直接反馈。

Q：数据包描述显示"pack.version2.moa.xxx"？
A：请检查lang.zip资源包是否加载。若已加载仍未解决，请把lang.zip和日志反馈给作者。

Q：如何修改配置？
A：输入指令/function config/root即可打开。

Q：找不到额外挑战进度？
A：额外挑战进度是隐藏的。只有你完成后才能看到。

Q：如何启用苦力怕世界？
A：进入配置选项，点击“更多数据包”，然后点击“【苦力怕世界】”下载。完成后导入，并重新加载世界。

Wzx1346798's Numerous Adv Pack
©2019-2023 wzx1346798. All rights reserved.
更新于2023年11月2日